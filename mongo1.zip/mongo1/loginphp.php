<?php
//session_start();
/*$login_id = "";
$password="";
 

// connect to the database
//$db = mysqli_connect('localhost', 'root', '', 'brainstormer');*/
session_start();
//$db = new MongoDB\Driver\Manager("mongodb://localhost:27017");
//$errors = array();
if (isset($_POST['login_user'])) {
  
	$login_id=$_POST['login_id'];
	$password=$_POST['password'];
  if (empty($login_id)) {
  	array_push($errors, "Username is required");
  }
  if (empty($password)) {
  	array_push($errors, "Password is required");
  }
	
  if($login_id=="E116004" and $password="Epassword")
  header("Location: dell-master/dashboard.html" ); 	
  /*if (count($errors) == 0) {
	 
	
	
		$filter=['login_id'=> $login_id, 'password'=>$password];
		$query = new MongoDB\Driver\Query($filter);

        $results =$db->executeQuery('brainstormer.login', $query);
		$check = count($results->toArray());
		if ($check == 1) {
  	 		 $_SESSION['login_id'] = $login_id;
  	  		 $_SESSION['success'] = "You are now logged in";
			 if($login_id[0]=="M")
    			header("Location: Manager.html"); 

			 if($login_id[0]=="E")
    			header("Location: Engineer.html"); 
  	  
  		}
  	}*/
}

?>