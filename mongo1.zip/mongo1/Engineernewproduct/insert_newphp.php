<?php
//session_start();
$Product_id = "";
$Product_info="";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', "brainstormer");
if (isset($_POST['submit'])) {
  
	$Product_id=$_POST['Product_id'];
	$Product_info=$_POST['Product_info'];
	

  	if (empty($Product_id)) {
  		array_push($errors, "Product_id is required");
  	}
  	if (empty($Product_info)) {
  		array_push($errors, "Product_info is required");
  	}
	if (count($errors) == 0) {
		
	 	$qry=mysqli_query($db,"SELECT * FROM `product` WHERE ProductNo='$Product_id' ");
		$rowCheck=mysqli_num_rows($qry);
    		if ($rowCheck>0) { // if data exist update the data
       			 mysqli_query($db,"UPDATE `product` SET `ProductInfo`='$Product_info' WHERE `ProductNo`='$Product_id'");  
    		}
    		else{ // insert the data if data is not exist
        		$sql="INSERT INTO `product` (`ProductNo`, `ProductInfo`) VALUES ('$Product_id','$Product_info')";
	 		mysqli_query($db,$sql);
			header("Location:Engineer_insert.html");
    		}

		
			
	 
	
  	}

}
$db->close();

?>

