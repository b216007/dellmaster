const express = require('express')
const bodyParser = require('body-parser')
const MongoClient = require('mongodb').MongoClient;
const mongoose = require('mongoose');
const cors = require('cors')
const app = express()
const http = require('http').Server(app);
app.use(cors())
app.use(bodyParser.urlencoded({ extended: false }))
const database="bom"
var url = "mongodb://localhost:27017/"+database

class Bom {

add(argument,callback) {
var collectionName="bom_data"
MongoClient.connect(url, function(err, db) {
if (err) throw err;
var dbo = db.db(database);
var myobj =argument
dbo.collection(collectionName).insertOne(myobj, function(err, res) {
if (err) throw err;
console.log("1 document inserted");
db.close();
return callback(true,'ok')
});
}); 
}

view(argument={},callback) {

MongoClient.connect(url, function(err, db) {
if (err) throw err;
var dbo = db.db(database);
dbo.collection("bom_data").find(argument).toArray(function(err, result) {
if (err) throw err;
console.log(34,result);
db.close();
return callback(false,result)
});
}); 
}

update(argument,callback) {
console.log(argument)
var collectionName="bom_data"
MongoClient.connect(url, function(err, db) {
if (err) throw err;
var dbo = db.db(database);
console.log(argument,100)
var newvalues = { $set: {spr:""} };
console.log(argument,newvalues,116)
dbo.collection(collectionName).updateOne(argument, newvalues, function(err, res) {
if (err) throw err;
//console.log(res);
db.close();
return callback(false,'ok')
});
}); 
}

delete(argument={},callback) {
MongoClient.connect(url, function(err, db) {
if (err) throw err;
var dbo = db.db(database);
console.log(argument)
var collectionName="bom_table"
dbo.collection(collectionName).deleteMany(argument, function(err, obj) {
if (err) throw err;
console.log("document deleted");
db.close();
return callback(true,'One user has been deleted')
});
}); 
}
}


class BomTable {

add(argument,callback) {
var collectionName="bom_data"
MongoClient.connect(url, function(err, db) {
if (err) throw err;
var dbo = db.db(database);
var myobj =argument
dbo.collection(collectionName).insertOne(myobj, function(err, res) {
if (err) throw err;
console.log("1 document inserted");
db.close();
return callback(true,'ok')
});
}); 
}

view(argument={},callback) {

MongoClient.connect(url, function(err, db) {
if (err) throw err;
var dbo = db.db(database);
dbo.collection("bom_table").find(argument).toArray(function(err, result) {
if (err) throw err;
console.log(34,result);
db.close();
return callback(false,result)
});
}); 
}

update(argument,callback) {
console.log(argument)
var collectionName="bom_table"
MongoClient.connect(url, function(err, db) {
if (err) throw err;
var dbo = db.db(database);
console.log(argument,100)
var newvalues = { $set: {spr:""} };
console.log(argument,newvalues,116)
dbo.collection(collectionName).updateOne(argument, newvalues, function(err, res) {
if (err) throw err;
//console.log(res);
db.close();
return callback(false,'ok')
});
}); 
}

delete(argument={},callback) {
MongoClient.connect(url, function(err, db) {
if (err) throw err;
var dbo = db.db(database);
console.log(argument)
var collectionName="bom_table"
dbo.collection(collectionName).deleteMany(argument, function(err, obj) {
if (err) throw err;
console.log("1 document deleted");
db.close();
return callback(true,'One user has been deleted')
});
}); 
}
}
app.post("/bom/add",function(req,res){
var bom=new Bom()
console.log(req.body)
if(req.body.c==undefined) {
	req.body.height=1
	console.log(req.body)
	bom.add(req.body,function(err,result){
		res.set('Content-Type', 'text/plain')
		res.send('ok')
	})
} else {
	bom.view({_id:mongoose.Types.ObjectId(req.body.c)},function(err,result){
		console.log(result[0].height,95)
		req.body.height=result[0].height+1
		console.log(req.body)
		bom.add(req.body,function(err,result){
			res.set('Content-Type', 'text/plain')
			res.send('ok')
		})

	})
}
})

app.post("/bom/view",function(req,res){
var bom=new Bom()
bom.view(res.body,function(err,result){
res.set('Content-Type', 'text/json')
res.send(JSON.stringify(result))
})
})

app.post("/bom/table",function(req,res){
	var bom=new BomTable()
	var body
	for (var key in req.body) {
		body=JSON.parse(key)
	}
	console.log(body)
	bom.add(body,function(err,result){
		res.set('Content-Type', 'text/plain')
		res.send('ok')
	})
})

app.get("/delete",function(req,res){
	var bom=new Bom()
	bom.delete({},function(err,result){
		console.log('deleted')
	})
})
http.listen(4000, function (err) {
  if (err) {
    throw err
  }
  var bom=new Bom()
  console.log('Server started on port 4000')
})